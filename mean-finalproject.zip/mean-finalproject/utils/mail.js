const nodemailer = require("nodemailer");
function sendEmails(subject , message , recipients , response){
    nodemailer.createTestAccount(error , account)=>{
        let trans = nodemailer.createTransport({
            service : 'gmail',
            auth : {
                user : 'rk5632952@gmail.com',
                pass : 'rahul12341234'

            }
        });

        let mailOptions = {
            from : '',
            to : recipients,
            subject : subject , 
            text : message
        };

        trans.sendEmails(mailOptions , (err,info)=>{
            if(error){
                response.send("cant send mail some error ");
            }
            else {
                res.send('congrats account has been created , check mail informtion '   )
            }
        })
    }
};

module.exports = sendEmails;