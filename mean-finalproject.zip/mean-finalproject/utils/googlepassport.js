const GoogleStategy = require("passport-google-oauth2");
const passport = require("passport");
//const connection = require('../db/models/userschema')
const User = require("../db/models/userschema");
// this will call  when u write a cookie 
passport.serializeUser((user,done)=>{
    var error = null;
    done(error , user);
    
});
// this will call  when u read data from cookie 
passport.deserializeUser((userid,done)=>{
    console.log("User Session" , userid);
    User.findById(userid).then(user=>{
        done(null,user);
    })

})
passport.use(new GoogleStategy({
    callbackURL : '/dashboard',
    clientID : '101809913093-trj499ivqsc8dg70f30rp688fnff40fs.apps.googleusercontent.com',
    clientSecret : '9cLWKzNW0Y724NUwK1_BlCdZ'
},(accessToken , refreshToken , profile , done)=>{
    console.log("callback google......" , profile , "Token " , accessToken);
    // var userObject = {
    //     email : profile._json.emails[0],
    //     name : profile._json.displayName,
    //     image: profile._json.image.url
    // }

    User.findOne({googleId:profile.id}).then(currentUser=>{
        if(currentUser){
            console.log("User Exists");
            done(null , currentUser);
        }
        else {
           var userObject =  new User({
                username : profile.displayName,
                googleId : profile.id,
                pic : profile._json.image.url,
                email : profile._json.emails[0].value,
            })
            userObject.save().then(newUser=>{
                 console.log("new user added");
                 let mail  = require('./mail');
                 mail("Account Created" , "account has been created Successfully ", profile._json.emails[0].value);
                 done(null, newUser);
            });
        }
    });
}));
   