const express = require('express');
const passport = require("passport");
const routes = express.Router();
const User = require("../db/models/userschema");
routes.get('/google' , passport.authenticate('google' , {scope: ['profile','email']}));
      
  routes.get('/dashboard' , passport.authenticate('google') , (req,res)=>{
   console.log("request" , req);
     let mail = require('../utils/mail');
     mail("account Created"  , "account has been created" , req.user.email , res);   
   res.render('dashboard'  , {
       name :  req.user.username,
       image : req.user.pic , 
       email : req.user.email
    });
});
   //res.send("Welcome user " +req.user.name);
   module.exports  = routes;