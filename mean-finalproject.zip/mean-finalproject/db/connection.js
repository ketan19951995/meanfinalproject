const mongooose = require('mongoose');
const config = require('./config');
//mongooose.connect('mongodb://admin:admin@123@ds255794.mlab.com:55794/finalproject',()=>{
  //  console.log("DB connected");
//});