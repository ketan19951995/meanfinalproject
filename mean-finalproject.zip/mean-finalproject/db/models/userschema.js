const mongoose = require('mongoose');
var Schema = mongoose.Schema;

const userSchema = new Schema (
    {userName:String,
        googleId : String,
        pic : String,
        email : String,
})


const User = mongoose.model("users" , userSchema);
module.exports = User;